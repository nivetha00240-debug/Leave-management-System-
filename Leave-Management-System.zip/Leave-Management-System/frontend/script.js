// Set this to your deployed Render backend URL after deployment.
const API_URL = "https://YOUR-RENDER-BACKEND.onrender.com/api";

const form = document.getElementById("leaveForm");
const rows = document.getElementById("leaveRows");
const message = document.getElementById("message");

async function loadLeaves() {
  rows.innerHTML = '<tr><td colspan="7">Loading...</td></tr>';
  try {
    const response = await fetch(`${API_URL}/leaves`);
    if (!response.ok) throw new Error("Could not load leave requests");
    const leaves = await response.json();
    if (!leaves.length) {
      rows.innerHTML = '<tr><td colspan="7">No leave requests yet.</td></tr>';
      return;
    }
    rows.innerHTML = leaves.map(leave => `
      <tr>
        <td>${escapeHtml(leave.employee_name)}</td>
        <td>${escapeHtml(leave.department)}</td>
        <td>${escapeHtml(leave.leave_type)}</td>
        <td>${escapeHtml(leave.start_date)} to ${escapeHtml(leave.end_date)}</td>
        <td>${escapeHtml(leave.reason)}</td>
        <td class="status ${leave.status}">${leave.status}</td>
        <td>
          ${leave.status === "Pending" ? `
            <div class="action-buttons">
              <button onclick="updateStatus(${leave.id}, 'Approved')">Approve</button>
              <button class="reject" onclick="updateStatus(${leave.id}, 'Rejected')">Reject</button>
            </div>` : "—"}
        </td>
      </tr>`).join("");
  } catch (error) {
    rows.innerHTML = `<tr><td colspan="7">${escapeHtml(error.message)}. Check API_URL and backend deployment.</td></tr>`;
  }
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  message.textContent = "Submitting...";
  const data = {
    employee_name: document.getElementById("employeeName").value.trim(),
    department: document.getElementById("department").value.trim(),
    leave_type: document.getElementById("leaveType").value,
    start_date: document.getElementById("startDate").value,
    end_date: document.getElementById("endDate").value,
    reason: document.getElementById("reason").value.trim()
  };
  if (data.end_date < data.start_date) {
    message.textContent = "End date must be on or after start date.";
    return;
  }
  try {
    const response = await fetch(`${API_URL}/leaves`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Submission failed");
    form.reset();
    message.textContent = "Leave request submitted successfully.";
    loadLeaves();
  } catch (error) {
    message.textContent = error.message;
  }
});

async function updateStatus(id, status) {
  try {
    const response = await fetch(`${API_URL}/leaves/${id}`, {
      method: "PATCH",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({status})
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Update failed");
    loadLeaves();
  } catch (error) {
    alert(error.message);
  }
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  })[char]);
}

document.getElementById("refreshBtn").addEventListener("click", loadLeaves);
loadLeaves();
