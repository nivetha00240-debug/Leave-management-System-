LEAVE MANAGEMENT SYSTEM - DEPLOYMENT GUIDE

TECH STACK
Frontend: HTML, CSS, JavaScript (Vercel)
Backend: Node.js + Express (Render)
Database: PostgreSQL (Neon)

1. CREATE DATABASE
- Create a free PostgreSQL database at https://neon.tech
- Copy its connection string (DATABASE_URL).

2. DEPLOY BACKEND TO RENDER
- Upload/push this project to a GitHub repository.
- In Render, create a new Web Service and connect the repository.
- Root Directory: backend
- Build Command: npm install
- Start Command: npm start
- Add environment variable DATABASE_URL = your Neon connection string
- Add FRONTEND_URL = your Vercel website URL (you can update this after frontend deployment).
- Deploy. Copy the Render service URL.

3. CONNECT FRONTEND TO BACKEND
- Open frontend/script.js.
- Replace https://YOUR-RENDER-BACKEND.onrender.com with your actual Render URL.
- Commit and push the change to GitHub.

4. DEPLOY FRONTEND TO VERCEL
- In Vercel, import the same GitHub repository.
- Set Root Directory to frontend.
- Deploy.
- Copy the Vercel URL and add it to Render's FRONTEND_URL environment variable.
- Redeploy the backend if required.

5. TEST
- Open the Vercel website.
- Submit a leave request.
- Check that it appears in Leave Requests.
- Try Approve and Reject.

IMPORTANT
This is a beginner/demo project. It does not include employee/admin login or role-based security.
Before real use, add authentication and restrict approval actions to authorized administrators.
Keep DATABASE_URL private. Never put it in frontend/script.js or commit a real .env file.
