require("dotenv").config();
const express = require("express");
const cors = require("cors");
const pool = require("./db");

const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || "*" }));
app.use(express.json());

async function createTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS leaves (
      id SERIAL PRIMARY KEY,
      employee_name VARCHAR(100) NOT NULL,
      department VARCHAR(100) NOT NULL,
      leave_type VARCHAR(50) NOT NULL,
      start_date DATE NOT NULL,
      end_date DATE NOT NULL,
      reason TEXT NOT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'Pending',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);
}

app.get("/", (req, res) => res.send("Leave Management API is running"));

app.get("/api/health", (req, res) => res.json({ status: "ok" }));

app.get("/api/leaves", async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM leaves ORDER BY created_at DESC");
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Unable to fetch leave requests" });
  }
});

app.post("/api/leaves", async (req, res) => {
  const { employee_name, department, leave_type, start_date, end_date, reason } = req.body;
  if (!employee_name || !department || !leave_type || !start_date || !end_date || !reason) {
    return res.status(400).json({ error: "Please fill in all fields" });
  }
  if (end_date < start_date) {
    return res.status(400).json({ error: "End date must be on or after start date" });
  }
  try {
    const result = await pool.query(
      `INSERT INTO leaves
       (employee_name, department, leave_type, start_date, end_date, reason)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [employee_name, department, leave_type, start_date, end_date, reason]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Unable to save leave request" });
  }
});

app.patch("/api/leaves/:id", async (req, res) => {
  const { status } = req.body;
  if (!["Approved", "Rejected"].includes(status)) {
    return res.status(400).json({ error: "Status must be Approved or Rejected" });
  }
  try {
    const result = await pool.query(
      "UPDATE leaves SET status = $1 WHERE id = $2 RETURNING *",
      [status, req.params.id]
    );
    if (!result.rowCount) return res.status(404).json({ error: "Leave request not found" });
    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Unable to update leave request" });
  }
});

const PORT = process.env.PORT || 5000;
createTable()
  .then(() => app.listen(PORT, () => console.log(`Server running on port ${PORT}`)))
  .catch(error => {
    console.error("Database connection/table setup failed:", error);
    process.exit(1);
  });
